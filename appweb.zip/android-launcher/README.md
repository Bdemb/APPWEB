# Launcher C4 — Android (TS18, Android 11, 1024×600)

Application Android native minimale qui affiche l'interface web en plein écran
et sert d'écran d'accueil (launcher). Aucune modification du firmware.

## Compiler l'APK
1. Publier l'app web, puis mettre son adresse dans `app/build.gradle.kts`
   (`LAUNCHER_URL`).
2. Ouvrir le dossier `android-launcher` dans Android Studio (Koala ou plus récent, JDK 17).
3. Laisser Android Studio synchroniser Gradle (il génère le wrapper si demandé).
4. Menu **Build > Build APK(s)**. L'APK est dans `app/build/outputs/apk/debug/`.
   En ligne de commande : `gradle wrapper` puis `./gradlew assembleDebug`.

## Installer sur l'autoradio
- Copier l'APK sur une clé USB, l'ouvrir avec le gestionnaire de fichiers, autoriser les sources inconnues.
- Ou via ADB : `adb install -r app-debug.apk`.
- Appuyer sur Accueil et choisir **Launcher C4 > Toujours**.

## Ce qui fonctionne réellement
- Lancement des applications (listes de paquets de secours dans `src/lib/launcher.ts`).
- Tiroir « Applications » listant toutes les apps installées.
- Lecture/pause, précédent, suivant (touches média Android, contrôlent le lecteur actif).
- Appeler / Clavier / Contacts (intents Android standard).
- Bascule jour/nuit (palette complète, mémorisée).

## Ce qui est uniquement visuel
- Données véhicule (carburant, état, portes) : affichées « Non connecté ».
- Climatisation : affichage seul, aucune commande envoyée au véhicule.
- Carte, guidage, morceau en cours, météo : aperçus. Toucher la carte ouvre Maps.

## Icône de l'app
Ajouter `app/src/main/res/mipmap-*/ic_launcher.png` (Android Studio :
clic droit `res` > New > Image Asset).
