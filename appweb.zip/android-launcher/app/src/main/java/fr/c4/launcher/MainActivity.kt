package fr.c4.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            isVerticalScrollBarEnabled = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
            }
            addJavascriptInterface(Bridge(this@MainActivity), "AndroidLauncher")
            loadUrl(BuildConfig.LAUNCHER_URL)
        }
        setContentView(web)
        hideSystemBars()
    }

    override fun onResume() { super.onResume(); hideSystemBars() }

    // A launcher must not exit on Back; only navigate inside the web UI.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    class Bridge(private val ctx: Context) {
        private val pm: PackageManager = ctx.packageManager

        @JavascriptInterface
        fun launchPackage(pkg: String): Boolean {
            val i = pm.getLaunchIntentForPackage(pkg) ?: return false
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try { ctx.startActivity(i); true } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun launchFirst(json: String): Boolean {
            val arr = JSONArray(json)
            for (k in 0 until arr.length()) if (launchPackage(arr.getString(k))) return true
            return false
        }

        @JavascriptInterface
        fun launchAction(action: String, data: String): Boolean {
            val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (data.isNotEmpty()) i.data = Uri.parse(data)
            return try { ctx.startActivity(i); true } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun mediaKey(code: Int) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }

        @JavascriptInterface
        fun listApps(): String {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val out = JSONArray()
            pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { ri ->
                    out.put(JSONObject()
                        .put("label", ri.loadLabel(pm).toString())
                        .put("packageName", ri.activityInfo.packageName)
                        .put("icon", iconData(ri.loadIcon(pm))))
                }
            return out.toString()
        }

        private fun iconData(d: android.graphics.drawable.Drawable): String {
            val b = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
            val c = Canvas(b); d.setBounds(0, 0, 72, 72); d.draw(c)
            val os = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 90, os); b.recycle()
            return "data:image/png;base64," + Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP)
        }
    }
}
