import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Cloud, CloudFog, CloudLightning, CloudMoon, CloudRain, CloudSnow, CloudSun, Moon, RefreshCw, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { weatherCondition, weatherOptions } from "@/lib/weather";

export function Weather() {
  const [ready, setReady] = useState(false);
  const [now, setNow] = useState(0);
  const refetchRef = useRef<(() => void) | null>(null);
  useEffect(() => {
    setReady(true);
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 60000);
    const onRefresh = () => void refetchRef.current?.();
    window.addEventListener("c4-refresh", onRefresh);
    return () => { clearInterval(timer); window.removeEventListener("c4-refresh", onRefresh); };
  }, []);
  const { data, isError, isFetching, refetch } = useQuery({ ...weatherOptions, enabled: ready });
  refetchRef.current = isFetching ? null : () => refetch();
  const condition = weatherCondition(data?.weather_code ?? -1);
  const icons = {
    clear: data?.is_day === 0 ? Moon : Sun,
    partly: data?.is_day === 0 ? CloudMoon : CloudSun,
    cloud: Cloud, fog: CloudFog, rain: CloudRain, snow: CloudSnow, storm: CloudLightning,
  };
  const Icon = data ? icons[condition.icon] : Cloud;
  const stale = data && now - data.fetchedAt > 45 * 60 * 1000;
  const status = isError || stale ? "Non actualisée" : data ? `${condition.label} · ${data.time.slice(11, 16)}` : isFetching || !ready ? "Actualisation…" : "Indisponible";

  return (
    <Button variant="ghost" className="h-auto max-w-[190px] gap-2 px-1 py-0 text-left font-normal" aria-label="Actualiser la météo de Douai" title={`Douai · Open-Meteo · ${status}`} onClick={() => void refetch()} disabled={isFetching}>
      {isFetching ? <RefreshCw className="size-6 shrink-0 animate-spin text-muted-foreground motion-reduce:animate-none" /> : <Icon className={`size-7 shrink-0 ${condition.icon === "clear" && data?.is_day === 1 ? "text-chart-4" : "text-muted-foreground"}`} />}
      <div className="min-w-0 leading-tight" role="status" aria-live="polite">
        <div className="text-lg font-bold">{data && !stale ? `${Math.round(data.temperature_2m)}°C` : "—°C"}</div>
        <div className="text-[11px]">Douai</div>
        <div className="truncate text-[10px] text-muted-foreground">{status}</div>
      </div>
    </Button>
  );
}