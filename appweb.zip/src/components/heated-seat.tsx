import seatIcon from "@/assets/icons/climate-seat.png.asset.json";

export function HeatedSeat({ side, night }: { side: "gauche" | "droit"; night?: boolean }) {
  return (
    <img
      src={seatIcon.url}
      alt={`Siège chauffant ${side} — non connecté`}
      title={`Siège chauffant ${side} — non connecté`}
      className={`shrink-0 ${night ? "climate-icon-night" : ""}`}
      style={{ height: 26, width: "auto" }}
    />
  );
}
