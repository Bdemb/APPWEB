import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  Home, Navigation, Music, Phone, Radio, Car, Settings, Bluetooth, Wifi, MapPin,
  BatteryCharging, Monitor, Sun, Moon, CornerUpRight, Volume2, Plus, Minus, Heart,
  SkipBack, SkipForward, Pause, Play, Fuel, Lock,
  CheckCircle2, ChevronLeft, ChevronRight, ChevronDown, Wind, X, ExternalLink, RefreshCw,
} from "lucide-react";
import fanIcon from "@/assets/icons/climate-fan.png.asset.json";
import carImg from "@/assets/car-c4-2009-red.jpg";
import carImgDay from "@/assets/car-c4-2009-red-day.jpg";
import mapImg from "@/assets/map.jpg";
import mapsIcon from "@/assets/icons/maps.png";
import wazeIcon from "@/assets/icons/waze.png";
import albumImg from "@/assets/album.jpg";
import mapsAsset from "@/assets/icons/maps.png.asset.json";
import spotifyAsset from "@/assets/icons/spotify2.png.asset.json";
import radioAsset from "@/assets/icons/radio.png.asset.json";
import youtubeAsset from "@/assets/icons/youtube-circle.png.asset.json";
import phoneAsset from "@/assets/icons/phone.png.asset.json";
import carplayAsset from "@/assets/icons/carplay.png.asset.json";
import citroenAsset from "@/assets/icons/citroen.png.asset.json";
import watchIconsAsset from "@/assets/icons/watch-icons.png.asset.json";
import watchIconsDarkAsset from "@/assets/icons/watch-icons-dark.png.asset.json";
import { Button } from "@/components/ui/button";
import { HeatedSeat } from "@/components/heated-seat";
import { Weather } from "@/components/weather";
import { MAP_PROVIDERS, type MapProvider } from "@/lib/map-providers";
import {
  APP_TARGETS, isAndroid, launch, launchAction, launchPackage, listApps, mediaKey, MEDIA,
  type InstalledApp,
} from "@/lib/launcher";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Launcher C4 — Autoradio TS18" },
      { name: "description", content: "Launcher autoradio 1024×600 : navigation, musique, téléphone, mode jour/nuit." },
      { property: "og:title", content: "Launcher C4 — Autoradio TS18" },
      { property: "og:description", content: "Launcher autoradio 1024×600 : navigation, musique, téléphone, mode jour/nuit." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

type Key = keyof typeof APP_TARGETS | "apps";

const icMaps = mapsAsset.url, icSpotify = spotifyAsset.url, icRadio = radioAsset.url;
const icYoutube = youtubeAsset.url, icPhone = phoneAsset.url, icCarplay = carplayAsset.url;
const icCitroen = citroenAsset.url;
const icWatchIcons = watchIconsAsset.url;
const icWatchIconsDark = watchIconsDarkAsset.url;


const dockImg = (src: string) => (
  <img src={src} alt="" width={52} height={52} loading="lazy" className="h-full w-full object-cover" />
);

// Symbole Bluetooth officiel (rune) sur une tuile arrondie.
const bluetoothTile = (
  <svg viewBox="0 0 52 52" className="block" style={{ width: "100%", height: "100%" }} role="img" aria-label="Bluetooth">
    <rect width="52" height="52" className="fill-primary" />
    <path
      d="M16 17 36 35 26 42 V10 L36 17 16 35"
      fill="none"
      strokeWidth={3.5}
      strokeLinejoin="round"
      strokeLinecap="round"
      className="stroke-primary-foreground"
    />
  </svg>
);

// Icône « Applications » style Apple CarPlay : carré arrondi noir dans une pastille blanche.
const appsTile = (
  <svg viewBox="0 0 52 52" className="block" style={{ width: "100%", height: "100%" }} role="img" aria-label="Applications">
    <circle cx="26" cy="26" r="24.2" stroke="var(--icon-edge)" strokeWidth="1.6" className="fill-primary-foreground" />
    <rect
      x="16" y="16" width="20" height="20" rx="6"
      fill="none"
      strokeWidth={3.2}
      strokeLinejoin="round"
      className="stroke-apps-glyph"
    />
  </svg>
);

const dock: { key: Key; label: string; icon: ReactNode }[] = [
  { key: "maps", label: "Navigation", icon: dockImg(icMaps) },
  { key: "music", label: "Musique", icon: dockImg(icSpotify) },
  { key: "radio", label: "Radio", icon: dockImg(icRadio) },
  { key: "video", label: "Vidéo", icon: dockImg(icYoutube) },
  { key: "bluetooth", label: "Bluetooth", icon: bluetoothTile },
  { key: "carplay", label: "CarPlay", icon: dockImg(icCarplay) },
  { key: "citroen", label: "Citroën", icon: dockImg(icCitroen) },
  { key: "apps", label: "Applications", icon: appsTile },
];

const side: { icon: typeof Home; label: string; key?: Key }[] = [
  { icon: Home, label: "Accueil" },
  { icon: Navigation, label: "Navigation", key: "maps" },
  { icon: Music, label: "Musique", key: "music" },
  { icon: Phone, label: "Téléphone", key: "bluetooth" },
  { icon: Radio, label: "Radio", key: "radio" },
  { icon: Car, label: "Véhicule", key: "citroen" },
  { icon: Settings, label: "Réglages" },
];

const W = 1024, H = 600;

function Dashboard() {
  const [now, setNow] = useState<Date | null>(null);
  const [scale, setScale] = useState(1);
  const [night, setNight] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [liked, setLiked] = useState(false);
  const [tL, setTL] = useState(22);
  const [tR, setTR] = useState(22);
  const [fan, setFan] = useState(3);
  const [ac, setAc] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [notice, setNotice] = useState<string | null>(null);
  const [drawer, setDrawer] = useState<InstalledApp[] | null>(null);
  const [mapProvider, setMapProvider] = useState<MapProvider>("google");
  const [mapPreview, setMapPreview] = useState(false);
  const [mapReload, setMapReload] = useState(0);
  const [preferencesReady, setPreferencesReady] = useState(false);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 15000);
    const fit = () => setScale(Math.min(window.innerWidth / W, window.innerHeight / H));
    fit();
    window.addEventListener("resize", fit);
    const saved = localStorage.getItem("night") === "1";
    setNight(saved);
    setMapProvider(localStorage.getItem("map-provider") === "waze" ? "waze" : "google");
    setPreferencesReady(true);
    return () => { clearInterval(t); window.removeEventListener("resize", fit); };
  }, []);
  useEffect(() => {
    if (!preferencesReady) return;
    document.documentElement.classList.toggle("dark", night);
    localStorage.setItem("night", night ? "1" : "0");
    localStorage.setItem("map-provider", mapProvider);
  }, [night, mapProvider, preferencesReady]);
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(null), 2500);
    return () => clearTimeout(t);
  }, [notice]);

  const open = (key: Key, label: string) => {
    if (!isAndroid()) return setNotice(`« ${label} » s'ouvrira dans l'APK`);
    if (key === "apps") return setDrawer(listApps());
    if (key === "maps") {
      if (!launchPackage(MAP_PROVIDERS[mapProvider].packageName)) setNotice(`${MAP_PROVIDERS[mapProvider].label} introuvable sur l'autoradio`);
      return;
    }
    if (!launch(key)) setNotice(`Application « ${label} » introuvable sur l'autoradio`);
  };
  const chooseMap = (provider: MapProvider) => {
    setMapProvider(provider);
    if (isAndroid()) {
      setMapPreview(false);
      setNotice(`Ouvrez ${MAP_PROVIDERS[provider].label} avec la flèche ; aperçu intégré indisponible dans l'APK actuel`);
      return;
    }
    setMapPreview(true);
  };
  const openSelectedMap = () => {
    if (isAndroid()) return open("maps", MAP_PROVIDERS[mapProvider].label);
    window.open(MAP_PROVIDERS[mapProvider].webUrl, "_blank", "noopener,noreferrer");
  };
  const action = (a: string, label: string, data = "") => {
    if (!isAndroid()) return setNotice(`« ${label} » s'ouvrira dans l'APK`);
    if (!launchAction(a, data)) setNotice(`« ${label} » indisponible`);
  };
  const media = (code: number) => {
    if (!isAndroid()) setNotice("Commandes média actives dans l'APK");
    mediaKey(code);
    if (code === MEDIA.PLAY_PAUSE) setPlaying((p) => !p);
  };


  const time = now ? now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }) : "--:--";
  const date = now
    ? now.toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short", year: "numeric" })
    : "";

  return (
    <div className="fixed inset-0 overflow-hidden bg-bezel font-sans">
      <div
        className="absolute left-1/2 top-1/2 select-none bg-background text-foreground"
        style={{ width: W, height: H, transform: `translate(-50%,-50%) scale(${scale})` }}
      >
        <div className="flex h-full flex-col gap-2 p-2">
          {/* Status bar — capsule style */}
          <header className="flex h-11 shrink-0 items-center">
            <div className="relative flex h-full flex-1 items-center gap-4 rounded-full border border-border bg-surface px-4 shadow-[var(--shadow-card)]">
              <span className="text-2xl font-black tracking-wide tabular-nums">{time}</span>
              <span className="text-sm capitalize text-muted-foreground">{date}</span>
              <div className="ml-auto flex items-center gap-4 text-xs font-semibold">
                <Bluetooth className="size-4" />
                <span aria-label="Signal réseau : 3 sur 5" className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <span key={i} className={`size-2 rounded-full ${i <= 3 ? "bg-current" : "border-2 border-current"}`} />
                  ))}
                </span>
                <Wifi className="size-5" strokeWidth={2.75} /><MapPin className="size-4" />
                <span className="flex items-center gap-1"><BatteryCharging className="size-4" />14.5V</span>
                <Monitor className="size-4" />
                <button onClick={() => open("apps", "Applications")} aria-label="Ouvrir les applications" className="text-muted-foreground active:scale-90">
                  <ChevronDown className="size-5" />
                </button>
              </div>
              <span aria-hidden className="pointer-events-none absolute inset-x-24 bottom-[3px] h-[3px] rounded-full bg-gradient-to-r from-transparent via-primary to-transparent opacity-80 blur-[1px]" />
            </div>
          </header>

          <div className="flex min-h-0 flex-1 gap-2">
            {/* Sidebar */}
            <nav className="flex w-[76px] shrink-0 flex-col justify-between">
              {side.map(({ icon: I, label, key }, i) => (
                <button key={label}
                  onClick={() => (key ? open(key, label) : label === "Réglages" ? action("android.settings.SETTINGS", label) : null)}
                  className={`flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-semibold transition-colors active:bg-muted ${i === 0 ? "bg-accent text-accent-foreground" : ""}`}>
                  <I className="size-5" />{label}
                </button>
              ))}
            </nav>

            <div className="flex min-w-0 flex-1 flex-col gap-2">
              <div className="flex min-h-0 flex-1 gap-2">
                {/* Vehicle */}
                <section className="card-soft flex w-[372px] shrink-0 flex-col overflow-hidden">
                  <div className="flex h-14 items-center justify-between px-3">
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col items-center leading-none">
                        <img src={icCitroen} alt="" width={30} height={30} className="size-7 rounded-md" />
                        <span className="mt-0.5 text-[10px] font-extrabold tracking-[0.2em]">CITROËN</span>
                      </div>
                    </div>
                    <Weather />
                  </div>
                  <div className="relative min-h-0 flex-1">
                    <img src={carImg} alt="Citroën C4 2009 rouge, phares allumés" width={1280} height={800} className={`vehicle-photo-fade absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${night ? "opacity-100" : "opacity-0"}`} />
                    <img src={carImgDay} alt="Citroën C4 2009 rouge" width={1280} height={800} className={`vehicle-photo-fade absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${night ? "opacity-0" : "opacity-100"}`} />
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 p-1.5">
                    <Stat icon={Fuel} title="Carburant">
                      <div className="text-sm font-bold">— <span className="text-[10px] font-normal">km</span></div>
                      <div className="mt-0.5 h-1 rounded-full bg-muted" />
                    </Stat>
                    <Stat icon={Car} title="Véhicule"><Status label="Bon état" /></Stat>
                    <Stat icon={Lock} title="Portes"><Status label="Verrouillées" /></Stat>
                  </div>
                </section>

                <div className="flex min-w-0 flex-1 flex-col gap-2">
                  {/* Navigation */}
                  <section className="card-soft relative min-h-0 flex-1 overflow-hidden">
                    {mapPreview && !isAndroid() ? (
                      <iframe key={`${mapProvider}-${mapReload}`} title={`Aperçu ${MAP_PROVIDERS[mapProvider].label}`} src={MAP_PROVIDERS[mapProvider].embedUrl} className="absolute inset-0 h-full w-full border-0" sandbox="allow-scripts allow-same-origin allow-popups" referrerPolicy="no-referrer" />
                    ) : <button className="absolute inset-0" onClick={() => chooseMap(mapProvider)} aria-label="Afficher l’aperçu de la carte">
                      <img src={mapImg} alt="" width={1280} height={720} style={{ transform: `scale(${zoom})` }}
                        className="h-full w-full object-cover transition-transform duration-300 dark:brightness-[0.55] dark:invert-[0.9] dark:hue-rotate-180" />
                    </button>}
                    <div className="absolute inset-x-2 top-2 flex items-center justify-between gap-2">
                      <div role="group" aria-label="Choix de la carte" className="flex rounded-lg border border-border bg-card p-0.5 shadow-sm">
{(Object.keys(MAP_PROVIDERS) as MapProvider[]).map((provider) => (
                          <Button key={provider} size="icon" variant={mapProvider === provider ? "default" : "ghost"} aria-pressed={mapProvider === provider} aria-label={MAP_PROVIDERS[provider].label} title={MAP_PROVIDERS[provider].label} onClick={() => chooseMap(provider)} className="h-7 w-9 p-0.5">
                            <img src={provider === "google" ? mapsIcon : wazeIcon} alt="" width={24} height={24} className="size-6 rounded-md" />
                          </Button>
                        ))}
                      </div>
                      <div className="flex gap-1">
                        {mapPreview && <Button size="icon" variant="secondary" className="size-8" aria-label="Recharger la carte" title="Recharger la carte" onClick={() => setMapReload((n) => n + 1)}><RefreshCw /></Button>}
                        <Button size="icon" variant="secondary" className="size-8" aria-label={`Ouvrir ${MAP_PROVIDERS[mapProvider].label}`} title={`Ouvrir ${MAP_PROVIDERS[mapProvider].label}`} onClick={openSelectedMap}><ExternalLink /></Button>
                      </div>
                    </div>
                    {!mapPreview && <><div className="pointer-events-none absolute left-2 top-12 flex items-center gap-2 rounded-lg bg-panel px-3 py-1.5 text-primary-foreground">
                      <CornerUpRight className="size-7" />
                      <div className="leading-tight">
                        <div className="text-lg font-bold">800 <span className="text-xs">m</span></div>
                        <div className="text-[11px]">Rue de Lille</div>
                        <span className="rounded bg-chart-4 px-1 text-[9px] font-bold text-panel">D917</span>
                      </div>
                    </div>
                    <div className="pointer-events-none absolute right-12 top-12 flex size-10 items-center justify-center rounded-full border-4 border-danger bg-card text-sm font-extrabold">50</div>
                    <div className="absolute bottom-2 right-2 flex flex-col overflow-hidden rounded-lg bg-card text-xs">
                      <MapBtn>3D</MapBtn>
                      <MapBtn><Volume2 className="size-4" /></MapBtn>
                      <MapBtn onClick={() => setZoom((z) => Math.min(z + 0.2, 2))}><Plus className="size-4" /></MapBtn>
                      <MapBtn onClick={() => setZoom((z) => Math.max(z - 0.2, 1))}><Minus className="size-4" /></MapBtn>
                    </div>
                    <div className="pointer-events-none absolute bottom-2 left-2 rounded-lg bg-card px-3 py-1 leading-tight">
                      <div className="text-base font-bold">13:14</div>
                      <div className="text-[11px] text-muted-foreground">17 min • 12 km · aperçu</div>
                    </div></>}
                  </section>

                  <div className="grid h-[132px] shrink-0 grid-cols-[1fr_0.9fr] gap-2">
                    {/* Music */}
                    <section className="card-soft flex flex-col justify-between p-2">
                      <div className="flex gap-2">
                        <button onClick={() => open("music", "Musique")} className="shrink-0">
                          <img src={albumImg} alt="Pochette" width={56} height={56} loading="lazy" className="size-14 rounded-lg object-cover" />
                        </button>
                        <div className="min-w-0 flex-1 leading-tight">
                          <div className="truncate text-sm font-bold">Tiakola</div>
                          <div className="truncate text-xs">Mélodie</div>
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground"><span className="app-icon-frame flex size-4 shrink-0"><img src={icSpotify} alt="" className="h-full w-full object-cover" /></span>Spotify · aperçu</div>
                        </div>
                        <button onClick={() => setLiked(!liked)} aria-label="J'aime" className="self-start">
                          <Heart className={`size-4 ${liked ? "fill-danger text-danger" : ""}`} />
                        </button>
                      </div>
                      <div className="flex items-center justify-center gap-7">
                        <button aria-label="Précédent" onClick={() => media(MEDIA.PREVIOUS)} className="active:scale-90"><SkipBack className="size-5 fill-foreground" /></button>
                        <button aria-label="Lecture/Pause" onClick={() => media(MEDIA.PLAY_PAUSE)} className="active:scale-90">
                          {playing ? <Pause className="size-6 fill-foreground" /> : <Play className="size-6 fill-foreground" />}
                        </button>
                        <button aria-label="Suivant" onClick={() => media(MEDIA.NEXT)} className="active:scale-90"><SkipForward className="size-5 fill-foreground" /></button>
                      </div>
                      <div className="flex items-center gap-1.5 text-[9px] tabular-nums">
                        1:25<div className="h-1 flex-1 rounded-full bg-muted"><div className="h-full w-[45%] rounded-full bg-primary" /></div>3:12
                      </div>
                    </section>

                    {/* Mini lanceur — toute la carte est cliquable et ouvre les Applications */}
                    <section className="card-soft p-2">
                      <button
                        onClick={() => open("apps", "Applications")}
                        aria-label="Ouvrir les Applications"
                        className="relative flex h-[120px] items-center justify-center rounded-xl transition-transform active:scale-[0.98]"
                        style={{ width: "100%" }}
                      >
                        <img
                          src={night ? icWatchIconsDark : icWatchIcons}
                          alt=""
                          aria-hidden="true"
                          draggable={false}
                          className="pointer-events-none select-none"
                          style={{ height: "100%", width: "100%", objectFit: "contain" }}
                        />
                      </button>
                    </section>
                  </div>
                </div>
              </div>

              {/* Dock */}
              <section className="card-soft grid h-[92px] shrink-0 grid-cols-8 items-center px-2">
                {dock.map(({ key, label, icon }) => (
                  <Button variant="ghost" key={key} onClick={() => open(key, label)}
                    className="h-auto flex-col gap-1 py-1 text-[11px] font-semibold transition-transform active:scale-90">
                    <span className="app-icon-frame flex size-[52px]">{icon}</span>
                    {label}
                  </Button>
                ))}
              </section>
            </div>
          </div>

          {/* Climate (decorative, not connected to the vehicle) */}
          <footer className="card-soft flex h-12 shrink-0 items-center justify-between px-3">
            <Temp v={tL} set={setTL} />
            <HeatedSeat side="gauche" night={night} />
            <Wind className="size-5 text-muted-foreground" />
            <div className="flex w-48 items-center gap-2">
              <img src={fanIcon.url} alt="" className={`shrink-0 ${night ? "climate-icon-night" : ""}`} style={{ height: 20, width: "auto" }} /><span className="text-sm font-bold">{fan}</span>
              <input type="range" min={0} max={7} value={fan} onChange={(e) => setFan(+e.target.value)} className="flex-1 accent-primary" aria-label="Ventilation (affichage)" />
            </div>
            <HeatedSeat side="droit" night={night} />
            <button onClick={() => setNight(!night)} className="flex items-center gap-2" aria-label="Mode jour/nuit">
              <Sun className={`size-5 ${!night ? "text-chart-4" : "text-muted-foreground"}`} />
              <span className={`flex h-6 w-11 items-center rounded-full p-0.5 transition-colors ${!night ? "bg-primary" : "bg-muted"}`}>
                <span className={`size-5 rounded-full bg-card shadow transition-transform ${!night ? "translate-x-5" : ""}`} />
              </span>
              <Moon className={`size-5 ${night ? "text-primary" : "text-muted-foreground"}`} />
            </button>
            <Button variant="ghost" role="switch" aria-checked={ac} aria-label="A/C — affichage non connecté" title="A/C — affichage non connecté" onClick={() => setAc((value) => !value)} className="h-9 gap-2 px-1.5 text-xs font-bold">
              A/C
              <span className={`flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition-colors ${ac ? "bg-primary" : "bg-muted"}`}>
                <span className={`size-5 rounded-full bg-card shadow transition-transform ${ac ? "translate-x-5" : ""}`} />
              </span>
            </Button>
            <Temp v={tR} set={setTR} />
          </footer>
        </div>

        {notice && (
          <div className="absolute bottom-16 left-1/2 -translate-x-1/2 rounded-full bg-panel px-4 py-2 text-xs text-primary-foreground shadow-lg">{notice}</div>
        )}

        {drawer && (
          <div className="absolute inset-0 flex flex-col bg-background/95 p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-bold">Applications</h2>
              <button onClick={() => setDrawer(null)} aria-label="Fermer"><X className="size-6" /></button>
            </div>
            <div className="grid flex-1 grid-cols-8 content-start gap-4 overflow-y-auto">
              {drawer.map((a) => (
                <button key={a.packageName} onClick={() => { launchPackage(a.packageName); setDrawer(null); }}
                  className="flex flex-col items-center gap-1 text-[11px]">
                  <img src={a.icon} alt="" width={48} height={48} className="size-12" />
                  <span className="w-full truncate">{a.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ icon: I, title, children }: { icon: typeof Fuel; title: string; children: ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 rounded-lg bg-surface p-1.5">
      <I className="size-5 shrink-0" />
      <div className="min-w-0 flex-1 text-[11px] leading-tight"><div className="truncate font-medium">{title}</div>{children}</div>
    </div>
  );
}
function Status({ label }: { label: string }) {
  return <div className="flex items-center gap-1 text-[9px] font-semibold text-success"><CheckCircle2 className="size-3 shrink-0" />{label}</div>;
}
function MapBtn({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return <button onClick={onClick} className="flex size-8 items-center justify-center border-b border-border font-bold last:border-0 active:bg-muted">{children}</button>;
}

function Temp({ v, set }: { v: number; set: (n: number) => void }) {
  return (
    <div className="flex items-center gap-1">
      <button aria-label="Moins" onClick={() => set(Math.max(16, v - 0.5))}><ChevronLeft className="size-5" /></button>
      <span className="w-16 text-center text-lg font-bold tabular-nums">{v.toFixed(1)}°C</span>
      <button aria-label="Plus" onClick={() => set(Math.min(30, v + 0.5))}><ChevronRight className="size-5" /></button>
    </div>
  );
}
