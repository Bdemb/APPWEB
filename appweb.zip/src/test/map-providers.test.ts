import { describe, expect, it } from "vitest";
import { MAP_PROVIDERS } from "@/lib/map-providers";

describe("Navigation provider choice", () => {
  it("pairs Google Maps preview with the Google Maps Android application", () => {
    expect(MAP_PROVIDERS.google.packageName).toBe("com.google.android.apps.maps");
    expect(new URL(MAP_PROVIDERS.google.embedUrl).hostname).toBe("maps.google.com");
    expect(new URL(MAP_PROVIDERS.google.embedUrl).searchParams.get("output")).toBe("embed");
  });
  it("pairs Waze preview with the Waze Android application", () => {
    expect(MAP_PROVIDERS.waze.packageName).toBe("com.waze");
    expect(new URL(MAP_PROVIDERS.waze.embedUrl).hostname).toBe("embed.waze.com");
  });
});