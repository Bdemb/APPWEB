import { describe, expect, it } from "vitest";
import { parseWeather, weatherCondition } from "@/lib/weather";

describe("Live weather", () => {
  it("uses the actual temperature, observation time and day/night from the provider", () => {
    expect(parseWeather({ current: { temperature_2m: 11.6, weather_code: 3, is_day: 0, time: "2026-10-22T21:15" } })).toEqual({ temperature_2m: 11.6, weather_code: 3, is_day: 0, time: "2026-10-22T21:15" });
  });
  it("rejects missing weather instead of substituting a demo temperature", () => {
    expect(() => parseWeather({ current: { weather_code: 0 } })).toThrow();
  });
  it("distinguishes clouds, rain, snow and thunderstorms from sunshine", () => {
    expect(weatherCondition(0).icon).toBe("clear");
    expect(weatherCondition(3).icon).toBe("cloud");
    expect(weatherCondition(61).icon).toBe("rain");
    expect(weatherCondition(85).icon).toBe("snow");
    expect(weatherCondition(95).icon).toBe("storm");
  });
});