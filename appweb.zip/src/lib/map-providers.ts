export const MAP_PROVIDERS = {
  google: {
    label: "Google Maps",
    packageName: "com.google.android.apps.maps",
    embedUrl: "https://maps.google.com/maps?q=Douai%2C%20France&z=14&output=embed",
    webUrl: "https://www.google.com/maps/search/?api=1&query=Douai%2C%20France",
  },
  waze: {
    label: "Waze",
    packageName: "com.waze",
    embedUrl: "https://embed.waze.com/iframe?zoom=12&lat=50.3679&lon=3.0807&language_code=fr",
    webUrl: "https://www.waze.com/live-map/directions?to=ll.50.3679%2C3.0807",
  },
} as const;

export type MapProvider = keyof typeof MAP_PROVIDERS;