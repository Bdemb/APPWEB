// Bridge between the web UI and the Android launcher shell (WebView JS interface "AndroidLauncher").
// In a normal browser the bridge is absent and actions are reported as unavailable.

export type InstalledApp = { label: string; packageName: string; icon: string };

type Bridge = {
  launchFirst(packagesJson: string): boolean;
  launchAction(action: string, data: string): boolean;
  mediaKey(keyCode: number): void;
  listApps(): string;
  launchPackage(pkg: string): boolean;
};

declare global {
  interface Window {
    AndroidLauncher?: Bridge;
  }
}

export const isAndroid = () => typeof window !== "undefined" && !!window.AndroidLauncher;

/** Candidate packages per tile, tried in order (head-unit firmwares vary). */
export const APP_TARGETS = {
  maps: ["com.google.android.apps.maps", "com.waze"],
  music: ["com.spotify.music", "com.google.android.apps.youtube.music"],
  radio: ["com.syu.radio", "com.android.fmradio", "com.ts.radio", "com.fyt.radio"],
  video: ["com.google.android.youtube", "com.liskovsoft.smarttubetv.beta"],
  bluetooth: ["com.syu.bt", "com.ts.bt", "com.android.bluetooth"],
  carplay: ["com.zjinnova.zlink", "com.zjinnova.zlink.ui", "com.autokit.autokit"],
  citroen: ["com.syu.canbus", "com.ts.canbus", "com.android.settings"],
} as const;

export function launch(key: keyof typeof APP_TARGETS): boolean {
  if (!window.AndroidLauncher) return false;
  return window.AndroidLauncher.launchFirst(JSON.stringify(APP_TARGETS[key]));
}

export function launchPackage(pkg: string): boolean {
  return window.AndroidLauncher?.launchPackage(pkg) ?? false;
}

export function launchAction(action: string, data = ""): boolean {
  return window.AndroidLauncher?.launchAction(action, data) ?? false;
}

export const MEDIA = { PLAY_PAUSE: 85, NEXT: 87, PREVIOUS: 88 };
export function mediaKey(code: number) {
  window.AndroidLauncher?.mediaKey(code);
}

export function listApps(): InstalledApp[] {
  try {
    return JSON.parse(window.AndroidLauncher?.listApps() ?? "[]");
  } catch {
    return [];
  }
}
