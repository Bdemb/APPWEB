import { queryOptions } from "@tanstack/react-query";
import { z } from "zod";

const weatherSchema = z.object({
  current: z.object({
    time: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/),
    temperature_2m: z.number().finite(),
    weather_code: z.number().int(),
    is_day: z.union([z.literal(0), z.literal(1)]),
  }),
});

export function parseWeather(value: unknown) {
  return weatherSchema.parse(value).current;
}

export function weatherCondition(code: number) {
  if (code === 0) return { label: "Ciel dégagé", icon: "clear" } as const;
  if (code === 1 || code === 2) return { label: "Éclaircies", icon: "partly" } as const;
  if (code === 3) return { label: "Couvert", icon: "cloud" } as const;
  if (code === 45 || code === 48) return { label: "Brouillard", icon: "fog" } as const;
  if ([71, 73, 75, 77, 85, 86].includes(code)) return { label: "Neige", icon: "snow" } as const;
  if ([95, 96, 99].includes(code)) return { label: "Orage", icon: "storm" } as const;
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return { label: "Pluie", icon: "rain" } as const;
  return { label: "Météo", icon: "cloud" } as const;
}

// Public, keyless weather request made only in the browser, including the Android WebView.
export const weatherOptions = queryOptions({
  queryKey: ["weather", "Douai"],
  queryFn: async ({ signal }) => {
    const controller = new AbortController();
    const abort = () => controller.abort();
    signal.addEventListener("abort", abort, { once: true });
    const timeout = setTimeout(abort, 12000);
    try {
      if (signal.aborted) controller.abort();
      const response = await fetch(
        "https://api.open-meteo.com/v1/forecast?latitude=50.3679&longitude=3.0807&current=temperature_2m,weather_code,is_day&timezone=Europe%2FParis",
        { signal: controller.signal },
      );
      if (!response.ok) throw new Error("Weather unavailable");
      return { ...parseWeather(await response.json()), fetchedAt: Date.now() };
    } finally {
      clearTimeout(timeout);
      signal.removeEventListener("abort", abort);
    }
  },
  staleTime: 5 * 60 * 1000,
  refetchInterval: 15 * 60 * 1000,
  refetchOnWindowFocus: true,
  refetchOnReconnect: true,
  retry: 1,
});